import { Component } from '@angular/core';
import { Store } from '@ngrx/store';
import {
  incrementAction,
  increment,
  decrementAction,
  decrement,
} from '../store/counter.action';

@Component({
  selector: 'app-counter-controls',
  templateUrl: './counter-controls.component.html',
  styleUrls: ['./counter-controls.component.css'],
})
export class CounterControlsComponent {
  constructor(private store: Store) {}

  increment() {
    //sect22:374 - dispatch the action & execute it
    //this.store.dispatch(increment({ value: 2 }));

    this.store.dispatch(new incrementAction(2));
  }

  decrement() {
    this.store.dispatch(decrement({ value: 1 }));
  }
}
