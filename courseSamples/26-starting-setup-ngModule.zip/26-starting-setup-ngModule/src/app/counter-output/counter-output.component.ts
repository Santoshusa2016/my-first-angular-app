import { Component } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { selectCount, selectDoubleCount } from '../store/counter.selector';

@Component({
  selector: 'app-counter-output',
  templateUrl: './counter-output.component.html',
  styleUrls: ['./counter-output.component.css'],
})
export class CounterOutputComponent {
  counter$: Observable<number>; //stores an observable which returns num
  doubleCounter$: Observable<number>;

  //Store here is the globally managed store by NgRx
  constructor(private store: Store<{ counter: number }>) {
    //sect26:372: get slice of store relative to counter reducer
    this.counter$ = store.select('counter');

    //sect26:379 - selector function
    this.doubleCounter$ = store.select(selectDoubleCount);
  }
}
