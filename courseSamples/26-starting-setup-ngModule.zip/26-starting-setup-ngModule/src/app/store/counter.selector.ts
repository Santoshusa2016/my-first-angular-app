import { createSelector } from '@ngrx/store';

//379: the anonymous function gets entire store as input with KVP
export const selectCount = (state: { counter: number }) => state.counter;

//createSelector function allows us to combine multiple selectors
// the input for our anonymous func is result of selectCount func
export const selectDoubleCount = createSelector(
  selectCount,
  (count) => count * 2
);
