import { of, switchMap, tap, withLatestFrom } from 'rxjs';
import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import { selectCount } from './counter.selector';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { decrement, increment, init, set } from './counter.action';

//sect26:382
@Injectable()
export class CounterEffects {
  constructor(
    private action$: Actions,
    private store: Store<{ counter: number }>
  ) {}

  //this.action$ is an observable
  savecount = createEffect(
    () =>
      this.action$.pipe(
        ofType(increment, decrement),
        withLatestFrom(this.store.select(selectCount)),
        tap((data) => {
          //tap allows to register a function without returning a new Observable
          const [action, counter] = data;
          console.log(action);
          //localStorage.setItem('count', action.value.toString());
          localStorage.setItem('count', counter.toString());
        })
      ),
    { dispatch: false } //sect26:381
  );

  //sect26: 386 Older way or registering effects
  @Effect({ dispatch: false })
  savecountfunc = this.action$.pipe(
    ofType(increment, decrement),
    withLatestFrom(this.store.select(selectCount)),
    tap(([action, counter]) => {
      //tap allows to register a function without returning a new Observable
      console.log(action);
      //localStorage.setItem('count', action.value.toString());
      localStorage.setItem('count', counter.toString());
    })
  );

  //sect26:386
  loadCount = createEffect(() =>
    this.action$.pipe(
      ofType(init),
      switchMap(() => {
        const storagecounter = localStorage.getItem('count');
        if (storagecounter) {
          //return an observable which wraps a new action
          //we also dont set dispatch prop
          return of(set({ value: +storagecounter }));
        } else {
          return of(set({ value: 0 }));
        }
      })
    )
  );
}

function Effect(arg0: {
  dispatch: boolean;
}): (target: CounterEffects, propertyKey: 'savecountfunc') => void {
  throw new Error('Function not implemented.');
}
