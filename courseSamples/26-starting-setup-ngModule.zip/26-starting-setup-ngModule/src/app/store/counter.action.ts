import { createAction, props, Action, on } from '@ngrx/store';

//sect22:377 - Define function & create enum for actions
export const INCREMENT = '[Counter] Increment';
export const DECREMENT = '[Counter] Decrement';

//sect22:373 - creating new action for invocation and processing
export const increment = createAction(
  '[Counter] Increment', //unique identifier
  props<{ value: number }>() //sect22:375 - Attaching data to actions
);

//380: Alternative way of defining Actions
export class incrementAction implements Action {
  readonly type = INCREMENT;
  //constructor(public payload: {value: number}) {}
  constructor(public value: number) {}
}

export const decrement = createAction(
  DECREMENT,
  props<{ value: number }>() //shape of data which we except
);

export class decrementAction implements Action {
  readonly type = DECREMENT;
  constructor(public value: number) {}
}

//custom type to combine all actions
export type CounterActions = incrementAction | decrementAction;

//sect26:385
//action to trigger side effect
export const init = createAction('[Counter] Init');

//action returned from side effect handled in reducer
export const set = createAction('[Counter] Set', props<{ value: number }>());
