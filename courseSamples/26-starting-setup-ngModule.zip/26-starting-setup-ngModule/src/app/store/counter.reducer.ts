import { Action, createReducer, on } from '@ngrx/store';
import {
  CounterActions,
  INCREMENT,
  incrementAction,
  increment,
  decrement,
  DECREMENT,
  decrementAction,
  set,
} from './counter.action';

/*this reducer manages counter[feature] specific data
reducer is like a utility function that takes input data and returns new data*/

const initialState: number = 0; //any datatype can be used text, bool, object, array

//sect26:370
export const counterReducer = createReducer(
  initialState,

  //sect26:373.
  on(increment, (currentState, action) => {
    return currentState + action.value; //Do not mutate old value
  }),
  on(decrement, (currentState, action) => currentState - action.value),
  on(set, (currentState, action) => action.value) //counter value returned from local storage
);

//sect26:371,377 - for older version of ngRx, nG
export function counterReducerFunc(
  currentState = initialState,
  action: CounterActions | Action
) {
  //a state of slice of data is maintained by this method
  if (action.type === INCREMENT)
    return currentState + (action as incrementAction).value;
  else if (action.type === DECREMENT)
    return currentState - (action as decrementAction).value;
  else return currentState;
}
