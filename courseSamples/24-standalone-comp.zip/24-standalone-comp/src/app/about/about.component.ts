import { Component } from '@angular/core';

@Component({
  standalone: true,
  templateUrl: './about.component.html'
})
export class AboutComponent {}
