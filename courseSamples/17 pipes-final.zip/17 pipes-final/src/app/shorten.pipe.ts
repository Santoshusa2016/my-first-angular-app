import { Pipe, PipeTransform } from '@angular/core';

//sect:246 - Custom Pipe
@Pipe({
  name: 'shorten'
})
export class ShortenPipe implements PipeTransform {
  transform(value: any, limit: number) {
    //must always have return type
    if (value.length > limit) {
      return value.substr(0, limit) + ' ...';
    }
    return value;
  }
}

