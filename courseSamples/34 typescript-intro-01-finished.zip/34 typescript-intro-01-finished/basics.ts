//496: Class
class Student {
  // firstName: string;
  // lastName: string;
  // age: number;
  // private courses: string[];

  constructor(
    public firstName: string,
    public lastName: string,
    public age: number,
    private courses: string[]
  ) {}

  enrol(courseName: string) {
    this.courses.push(courseName);
  }

  listCourses() {
    //original array is not modified
    return this.courses.slice();
  }
}

const student = new Student("Max", "Schwarz", 32, ["Angular"]);
student.enrol("React");
// student.listCourses(); => Angular, React
// student.courses => Angular, React

//497: Interfaces
interface Angel {
  firstName: string;
  age: number;
  message: () => void;
}

let priya: Angel;

priya = {
  firstName: "Babloo",
  age: 32,
  message() {
    console.log("I love you!");
  },
};

class Godess implements Angel {
  firstName: string;
  age: number;
  message() {
    console.log("Hello!!!!");
  }
}
