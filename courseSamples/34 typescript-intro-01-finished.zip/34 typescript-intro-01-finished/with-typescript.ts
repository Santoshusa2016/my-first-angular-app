//494: Diving into function & function types
function add(a: number, b: number): number | string {
  return a + b;
}

function print(value: any) {
  //void return type
  console.log(value);
}

const result = add(2, 5);
console.log(result);

//primitives
let isInstructor: boolean;
isInstructor = true;

//490: complex types
let hobbies: string[];
hobbies = ["learning", "cooking"];

let person: {
  name: string;
  age: number;
};

//if we directly assign obj, its of type any
person = {
  name: "Priya",
  age: 32,
};

let people: {
  name: string;
  age: number;
}[];

//491: type inference
let course = "React - The complete Guide";
//course = 1234; Error: typescript infers type

//492: union types
let angularCourse: string | number = "Angular - The Complete Guide";
angularCourse = 2023;
let userName: string | string[];
userName = ["Santosh", "Priya"];

//493: Assigning type alias
//lets type alias person which we use above.
type Person = {
  name: string;
  age: number;
};
let santosh: Person = {
  name: "Babloo",
  age: 37,
};
