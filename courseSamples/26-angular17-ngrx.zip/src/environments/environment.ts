export const environment = {
  production: true,
  firebaseAPIKey: 'xxxxxxxxxx'
};
