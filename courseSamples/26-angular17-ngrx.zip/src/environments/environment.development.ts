export const environment = {
  production: false,
  firebaseAPIKey: 'xxxxxxxxxx'
};
