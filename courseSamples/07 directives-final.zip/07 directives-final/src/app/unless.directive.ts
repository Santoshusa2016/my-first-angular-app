import { 
  Directive, 
  Input, 
  TemplateRef, 
  ViewContainerRef 
} from '@angular/core';

@Directive({
  selector: '[appUnless]'
})

export class UnlessDirective {
  /*sect100: Building strut directive => unless directive is opposite of if */

  //we want to execute a function when input property changes, hence we mark prop with setter.
  //we want the prop to be same name as selector for angular to bind when using prop syntax with square brackets
  @Input() set appUnless(condition: boolean) {
    if (!condition) {
      //here we use templateRef instead of elementRef because template is what we are going render in HTML
      this.vcRef.createEmbeddedView(this.templateRef);
    } else {
      this.vcRef.clear();
    }
  }

  constructor(private templateRef: TemplateRef<any>, 
    private vcRef: ViewContainerRef) { }

}
