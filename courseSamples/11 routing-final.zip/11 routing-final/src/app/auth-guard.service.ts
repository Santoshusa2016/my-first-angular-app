import {
  CanActivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  Router,
  CanActivateChild,
  createUrlTreeFromSnapshot,
} from '@angular/router';
import { Observable } from 'rxjs';
import { Injectable, inject } from '@angular/core';

import { AuthService } from './auth.service';

@Injectable()
export class AuthGuard implements CanActivate, CanActivateChild {
  constructor(private authService: AuthService, private router: Router) {}

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean> | Promise<boolean> | boolean {
    return this.authService.isAuthenticated().then((authenticated: boolean) => {
      if (authenticated) {
        return true;
      } else {
        this.router.navigate(['/']);
      }
    });
  }

  canActivateChild(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean> | Promise<boolean> | boolean {
    return this.canActivate(route, state);
  }
}

//function based route guard
export const authGuard = (next: ActivatedRouteSnapshot) => {
  return inject(AuthService)
    .isAuthenticated()
    .then((isAuthenticated: boolean) => {
      if (isAuthenticated) return true;
      else createUrlTreeFromSnapshot(next, ['/']);
    });
};
