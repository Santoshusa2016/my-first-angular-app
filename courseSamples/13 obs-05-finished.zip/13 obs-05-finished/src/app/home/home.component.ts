import { Component, OnDestroy, OnInit } from '@angular/core';

import { interval, Subscription, Observable } from 'rxjs';
import { map, filter } from 'rxjs/operators';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit, OnDestroy {
  private firstObsSubscription: Subscription;

  constructor() {
  }

  ngOnInit() {

    //sect:173
    //interval method allows to trigger events/ stream of data every x milliseconds
    this.firstObsSubscription = interval(1000).subscribe(count => {
      console.log(count);
    });

    //sect:174, custom observable. observer is one who is interested in our data
    const customIntervalObservable = new Observable(observer => {
      let count = 0;
      //setInterval event which executed every 1 second
      setInterval(() => {
        //next to emit new value        
        (count === 5) {
          observer.complete();
        }
        if (count > 3) {
          observer.error(new Error('Count is greater 3!'));
        }
        count++;
      }, 1000);
    });


    //sect:177
    //map takes func/predicate as an argument
    customIntervalObservable.pipe(
      filter((data: number)=> data>0)
      ,map((data: number) => {
      return "Round " + (data + 1);
    }));


    //subscribe to custom observable
    this.firstObsSubscription = customIntervalObservable.subscribe({
      next: (data) => console.log(data),
      error: (error) =>{
        console.log(error);
        alert(error.message);
      },
      complete: () => console.log('Completed!')
    });
  }


  ngOnDestroy(): void {
    //unsubscribe observable
    this.firstObsSubscription.unsubscribe();
  }

}
