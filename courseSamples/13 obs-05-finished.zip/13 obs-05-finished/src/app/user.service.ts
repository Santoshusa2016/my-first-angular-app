import { EventEmitter, Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({providedIn: 'root'})
export class UserService {
  //sect:178 Subjects
  //activatedEmitter : EventEmitter<boolean> = new EventEmitter();
  activatedEmitter = new Subject<boolean>();
}
