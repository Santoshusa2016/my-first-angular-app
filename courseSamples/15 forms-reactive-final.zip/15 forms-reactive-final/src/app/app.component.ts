import { Component, OnInit } from '@angular/core';
import { FormArray, FormControl, FormGroup, Validators } from '@angular/forms';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent implements OnInit {
  genders = ['male', 'female'];
  signupForm: FormGroup;
  forbiddenUsernames = ['Chris', 'Anna']; //sect:212 - custom validator

  constructor() {}

  ngOnInit() {
    //lifecycle hook called before rendering
    this.signupForm = new FormGroup({
      //add JSON form object
      userData: new FormGroup({
        username: new FormControl(null, [
          Validators.required,
          this.forbiddenNames.bind(this), //sect:213-binding to current instance.
        ]),
        email: new FormControl(
          null,
          [Validators.required, Validators.email], // we dont call method validations.required(), because we want angular to invoke it automatically whenever it needs it
          this.forbiddenEmails //sect:214
        ),
      }),
      gender: new FormControl('male'), //setting default value
      hobbies: new FormArray([]), //sect:211
    });

    /*sect:215 - subscribe to observables for status/value changes*/
    //we can also call this on individual form controls
    // this.signupForm.valueChanges.subscribe(
    //   (value) => console.log(value)
    // );
    this.signupForm.statusChanges.subscribe((status) => console.log(status));

    this.signupForm.setValue({
      userData: {
        username: 'Max',
        email: 'max@test.com',
      },
      gender: 'male',
      hobbies: [],
    });

    this.signupForm.patchValue({
      userData: {
        username: 'Anna',
      },
    });
  }

  onSubmit() {
    console.log(this.signupForm);
    this.signupForm.reset(); //sect:216 - To reset the form.
  }

  onAddHobby() {
    const control = new FormControl(null, Validators.required);
    (<FormArray>this.signupForm.get('hobbies')).push(control); //typecast control to formArray
  }

  //sect:212: custom validaton on control
  forbiddenNames(control: FormControl): { [s: string]: boolean } {
    //kvp: [s: string]: boolean }(forbidden:true)
    if (this.forbiddenUsernames.indexOf(control.value) !== -1) {
      return { nameIsForbidden: true };
    }
    return null; //if validation is successful pass nothing/null/omit return statement to tell ng that form control is valid
  }

  //sect:214 - async validatiors
  forbiddenEmails(control: FormControl): Promise<any> | Observable<any> {
    //returns promise
    const promise = new Promise<any>((resolve, reject) => {
      setTimeout(() => {
        if (control.value === 'test@test.com') {
          resolve({ emailIsForbidden: true });
        } else {
          resolve(null);
        }
      }, 1500);
    });
    return promise;
  }

  //sect:211
  get hobbyControls() {
    return (this.signupForm.get('hobbies') as FormArray).controls;
  }

  getControls() {
    return (<FormArray>this.signupForm.get('hobbies')).controls;
  }
  get controls() {
    return (this.signupForm.get('hobbies') as FormArray).controls;
  }
}
