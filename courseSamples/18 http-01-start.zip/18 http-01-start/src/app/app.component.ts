import { Component, OnDestroy, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Post } from './post.model';
import { PostService } from './post.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent implements OnInit, OnDestroy {
  loadedPosts: Post[] = [];
  isFetching = false;
  error = null;
  private errorSub: Subscription;
  constructor(private postService: PostService) {}

  ngOnInit() {
    this.errorSub = this.postService.error?.subscribe((errorMessage) => {
      this.error = errorMessage;
    });

    this.isFetching = true;
    //when page loads get the post
    this.fetchPosts();
  }

  //sect:266
  ngOnDestroy() {
    this.errorSub.unsubscribe();
  }

  //sect:256
  onCreatePost(postData: { title: string; content: string }) {
    // Send Http request
    this.postService.createPost(postData.title, postData.content);
  }

  onFetchPosts() {
    // Send Http request
    this.fetchPosts();
  }

  onClearPosts() {
    // Subscribing to delete post here to delete the loaded items
    this.postService.deletePosts().subscribe(() => {
      this.loadedPosts = [];
    });
  }

  //sect:257,258, 262
  private fetchPosts() {
    //I need response from service
    this.postService.fetchPosts().subscribe({
      next: (posts) => {
        this.loadedPosts = posts;
        this.isFetching = false;
      },
      error: (error) => {
        this.error = error.message;
        this.isFetching = false;
        console.log(this.error);
      },
    });
  }

  onHandleError() {
    this.error = null;
  }
}
