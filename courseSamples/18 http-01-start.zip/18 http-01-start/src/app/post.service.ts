import {
  HttpClient,
  HttpEventType,
  HttpHeaders,
  HttpParams,
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Post } from './post.model';
import { map, catchError, tap } from 'rxjs/operators';
import { Subject, throwError } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class PostService {
  error: Subject<string>; //sect:266
  constructor(private http: HttpClient) {}

  //this class will hold all HTTP methods
  createPost(title: string, content: string) {
    const postData: Post = { title: title, content: content };
    this.http
      .post<{ name: string }>(
        'https://ng-firstproject-9b62d-default-rtdb.firebaseio.com/posts.json',
        postData,
        {
          //sect:271 - get complete data payload
          observe: 'response',
        }
      )
      .subscribe({
        next: (respData) => {
          console.log(respData);
          console.log(respData.body); //response body
        },
        error: (error) => {
          //publish events via subject
          this.error.next(error.message);
        },
      });
  }

  fetchPosts() {
    //return observable
    return this.http
      .get(
        'https://ng-firstproject-9b62d-default-rtdb.firebaseio.com/posts.json',
        {
          //sect:269,270
          headers: new HttpHeaders({
            'Custom-Header': 'hello',
            'Access-Control-Allow-Origin': 'localhost',
          }),
          params: new HttpParams()
            .set('print', 'pretty')
            .append('custom', 'key'),
          responseType: 'json',
        }
      )
      .pipe(
        map((respData: { [key: string]: Post }) => {
          //above respose is created using dictionaryViaLiteral
          console.log(respData);

          //https://blog.logrocket.com/building-type-safe-dictionary-typescript/
          const postArray: Post[] = [];
          const dictionary: { [key: string]: string } = {};
          dictionary.firstName = 'Santosh';
          dictionary.LastName = 'Iyengar';

          for (const key in respData) {
            //ensure key exists in object & not comes from PROTOTYPE
            if (respData.hasOwnProperty(key)) {
              postArray.push({ ...respData[key], id: key });
            }
          }
          return postArray;
        }),
        catchError((errorRes) => {
          //https://www.tektutorialshub.com/angular/angular-catcherror/
          return throwError(() => new Error(errorRes)); //yield return new error
        })
      );
  }

  deletePosts() {
    return this.http
      .delete(
        'https://ng-firstproject-9b62d-default-rtdb.firebaseio.com/posts.json',
        {
          //sect:271
          observe: 'events',
          responseType: 'text',
        }
      )
      .pipe(
        tap((event) => {
          console.log(event);
          if (event.type == HttpEventType.Sent) {
            console.log(event.type);
          } else if (event.type == HttpEventType.Response) {
            console.log(event.body);
          }
        })
      );
  }
}
