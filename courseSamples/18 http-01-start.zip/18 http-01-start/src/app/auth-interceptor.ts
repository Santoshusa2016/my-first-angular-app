import {
  HttpInterceptor,
  HttpRequest,
  HttpHandler,
  HttpEventType,
} from '@angular/common/http';
import { tap } from 'rxjs/operators';

export class AuthInterceptorService implements HttpInterceptor {
  //sect:273
  intercept(req: HttpRequest<any>, next: HttpHandler) {
    if (req.url == 'something') {
      console.log('do not proceed');
    }

    console.log('Request on its way');
    var modifiedRequestObj = req.clone({
      url: 'https://www.google.com',
      headers: req.headers.append('lovers', 'priyaSantosh'),
    });

    //sect:275 - intercept response
    return next.handle(modifiedRequestObj);
  }
}
