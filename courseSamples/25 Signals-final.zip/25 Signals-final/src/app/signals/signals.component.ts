import { NgFor } from "@angular/common";
import { Component, signal, computed, effect } from "@angular/core";

@Component({
  selector: "app-signals",
  templateUrl: "./signals.component.html",
  standalone: true,
  imports: [NgFor],
})
export class SignalsComponent {
  actions = signal<string[]>([]); //sect25:361: pass initial value of array
  counter = signal(0); //wrapper around data object.

  //doubleCounter would be changes whenever counter changes
  doubleCounter = computed(() => this.counter() * 2); //sect25:365

  constructor() {
    effect(() => console.log(this.counter()));
  }

  increment() {
    // this.counter.update((oldCounter) => oldCounter + 1);
    // this.counter.set(5);
    this.counter.set(this.counter() + 1); //sect25:361. Execute the signal function to get prev value
    this.actions.mutate((oldActions) => oldActions.push("INCREMENT")); //mutable array
  }

  decrement() {
    this.counter.update((oldCounter) => oldCounter - 1);
    this.actions.update((oldActions) => [...oldActions, "DECREMENT"]); //create new array
  }
}
